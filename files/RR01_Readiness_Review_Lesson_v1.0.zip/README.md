# Readiness Review and Discrepancy Handoff

RR-01 v1.0 | Sean Kaspar | 17 October 2026

A proposed 90 minute classroom lesson using fictional source records. Timings and the proposed 16/18 threshold require pilot validation. No pilot results are claimed.

## Use
1. Read the instructor guide and evaluator key before facilitation.
2. Distribute only the learner packet for independent review. The full public package is not a secure exam.
3. Assess against the nine criteria and retain the submitted evidence.
4. Supply ED01 after independent assessment and develop the HOPS process and task revision. Keep evaluation pending until observed.
5. Record timing, scoring disagreements, usability issues and the next controlled revision.

## Contents
- Instructor guide, learner packet and evaluator guide in editable DOCX and printable PDF (4, 5 and 4 pages).
- lesson_specification.json: versioned design metadata, five reference findings and nine criterion anchors.
- RR01_HOPS_Exercise_Example.json: synthetic reference generated with the existing HOPS reducer. It stops at TRAINING_REVISED with no evaluation or closure. This is a reference file, not an automatic UI import.
- SHA256SUMS.txt: integrity hashes for the package contents.

## HOPS follow-through
https://seankaspar92.github.io/Portfolio/hops.html#improvement-loop

The browser stores a separate record per origin. Export before leaving. Use the learner paper worksheet if the site is unavailable. Neither paper completion nor this reference packet verifies software or learning outcomes.

## Scope
Independently developed administrative review and instructional improvement exercise. No company endorsement, service approval, equipment instruction, qualification or readiness authorization is implied. Correcting the record does not resolve inventory or revision gaps. Classroom role acceptance is simulated. FleetVoice verification remains deferred.
