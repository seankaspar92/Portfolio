# RR-01 pilot kit v1.0

Open RR01_Pilot_Worksheet.html in a browser and print. Copy the evaluator page for each learner, evaluator and attempt. Use aliases and keep original first attempts. The blank JSON is a manual record template, not an import to HOPS or the capture page.

Online capture: https://seankaspar92.github.io/Portfolio/rr01-pilot.html
Lesson: https://seankaspar92.github.io/Portfolio/readiness-lesson.html

The lesson proposes 90 minutes and a 16/18 pass with all five critical criteria at full credit. Record actual times, critical misses, criterion evidence, evaluator disagreements, usability issues, remediation and the next controlled lesson change. No completed human pilot or learning improvement is claimed by this kit. A synthetic rehearsal remains labeled synthetic.

Session records remain in the local browser until explicitly exported. Keep exported evidence privately. No identities, sensitive details, qualification, operational acceptance or FleetVoice verification are established by the tool.
